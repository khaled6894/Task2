<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "user_db";
$conn = new mysqli($host, $user, $pass, $db);

// لاضافة مستخدم 
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $stmt = $conn->prepare("INSERT INTO users (name, age) VALUES (?, ?)");
    $stmt->bind_param("si", $name, $age);
    $stmt->execute();
    $stmt->close();
    // اعادة تحميل الصفحة 
    header("Location: " . $_SERVER['PHP_SELF']);
    exit();
}
// Toggle لتغيير الحالة
if (isset($_POST['toggle'])) {
    $id = $_POST['id'];
    $current = $_POST['status'];
    $newStatus = $current == 1 ? 0 : 1;
// تحديث حالة في قاعدة البيانات
    $stmt = $conn->prepare("UPDATE users SET status=? WHERE id=?");
    $stmt->bind_param("ii", $newStatus, $id);
    $stmt->execute();
    $stmt->close();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Form</title>
    <style>
/* تنسيقات الصفحة */
    body { font-family: Arial; margin: 20px; }
    input[type=text], input[type=number] { padding: 5px; margin: 5px; }
    table { border-collapse: collapse; width: 100%; margin-top: 20px; }
    table, th, td { border: 1px solid black; padding: 8px; text-align: center; }
    button { padding: 5px 10px; }
    </style>
</head>
<body>
<!-- ادخال الاسم والعمر -->
<form method="POST">
    Name: <input type="text" name="name" required>
    Age: <input type="number" name="age" required>
    <input type="submit" name="submit" value="Submit">
</form>
<!-- عرض جميع المستخدمين في جدول -->
<table>
<tr>
<th>ID</th>
<th>Name</th>
<th>Age</th>
<th>Status</th>
<th>Action</th>
</tr>

<?php
// احضار جميع السجلات من جدول users
    $result = $conn->query("SELECT * FROM users");
    while ($row = $result->fetch_assoc()) {
// عرض كل مستخدم 
    echo "<tr>";
    echo "<td>{$row['id']}</td><td>{$row['name']}</td><td>{$row['age']}</td><td>{$row['status']}</td>";
// زر Toggle
    echo "<td>
         <form method='POST' style='display:inline'>
        <input type='hidden' name='id' value='{$row['id']}'>
        <input type='hidden' name='status' value='{$row['status']}'>
        <button type='submit' name='toggle'>Toggle</button>
        </form>
    </td>";
    echo "</tr>";
    }
    ?>
</table>
</body>
</html>